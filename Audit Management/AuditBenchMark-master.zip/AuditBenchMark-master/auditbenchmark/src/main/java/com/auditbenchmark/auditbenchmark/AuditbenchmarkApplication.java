package com.auditbenchmark.auditbenchmark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuditbenchmarkApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuditbenchmarkApplication.class, args);
	}

}
